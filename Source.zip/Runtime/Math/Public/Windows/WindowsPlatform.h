
#pragma once

#define FORCEINLINE __forceinline
