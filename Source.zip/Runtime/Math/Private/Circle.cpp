
#include "Precompiled.h"

Circle::Circle(const std::vector<Vector2> InVertices)
{
	// ��ġ ������ �޾� �߽ɰ� �������� ���� ���ϴ� ���� ( ���� ������ �� )

	/*Radius = (*std::max_element(InVertices.begin(), InVertices.end(),
		[&](Vector2 const& InLeft, Vector2 const& InRight)
	{
		return (Center - InLeft).SizeSquared() < (Center - InRight).SizeSquared();
	}
	)).Size();*/

	float sumX = 0.f;
	float sumY = 0.f;

	for (auto iter = InVertices.begin(); iter != InVertices.end(); ++iter)
	{
		sumX += iter->X;
		sumY += iter->Y;
	}
	Center = Vector2(sumX / InVertices.size(), sumY / InVertices.size());

	Vector2 temp = Vector2::Zero;
	for (auto iter = InVertices.begin(); iter != InVertices.end(); ++iter)
	{
		if ((pow(Center.X - iter->X, 2) + pow(Center.Y - iter->Y, 2)) > (pow(Center.X - temp.X, 2) + pow(Center.Y - temp.Y, 2)))
		{
			temp = Vector2(iter->X,iter->Y);
		}
	}
	Radius = sqrt(pow(Center.X - temp.X, 2) + pow(Center.Y - temp.Y, 2));
	
}
