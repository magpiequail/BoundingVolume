#include "Precompiled.h"

Rectangle::Rectangle(const std::vector<Vector2> InVertices)
{
	// 직접 구현해보시오.
	
	float minX = 0;
	float minY = 0;
	float maxX = 0;
	float maxY = 0;

	Vector2 temp = Vector2::Zero;
	for (auto iter = InVertices.begin(); iter != InVertices.end(); ++iter)
	{
		if(iter->X < minX )
		{
			minX = iter->X;
		}
		if (iter->X > maxX)
		{
			maxX = iter->X;
		}
		if (iter->Y < minY)
		{
			minY = iter->Y;
		}
		if (iter->Y > maxY)
		{
			maxY = iter->Y;
		}
		 
	}
	Min = Vector2(minX, minY);
	Max = Vector2(maxX, maxY);
	
}